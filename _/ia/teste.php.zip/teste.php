<?php
include("../bd/config.php");
include("../classes/usuarios_bot_whats.php");
include("../classes/w_api.php");

$ubw = new usuarios_bot_whats();
$numeroTeste = "554891174663";
$msgTeste = "👌 Teste de mensagem"; 

$mensagens = $ubw->get_msgs($numeroTeste);
var_dump($mensagens);
?>