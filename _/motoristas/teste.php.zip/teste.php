<?php
include("../classes/localizacao_corridas.php");
include("../classes/maps.php");
include("../classes/corridas.php");

$lc = new localizacao_corridas();
$m = new Maps();
$c = new corridas();

$corrida_id = $_POST['corrida_id'];

$dados_corrida = $c->get_corrida_id($corrida_id);
$lat_ini = $dados_corrida['lat_ini'];
$lng_ini = $dados_corrida['lng_ini'];
$lat_fim = $dados_corrida['lat_fim'];
$lng_fim = $dados_corrida['lng_fim'];

$coordenadas_corrida = $lc->getByCorridaId($corrida_id);


$waypoints = array();
foreach ($coordenadas_corrida as $key => $value) {
    $waypoints[] = $value['latitude'] . ',' . $value['longitude'];
}

$km = $m->calcularRota($lat_ini, $lng_ini, $waypoints, $lat_fim, $lng_fim);

echo json_encode($km);

?>